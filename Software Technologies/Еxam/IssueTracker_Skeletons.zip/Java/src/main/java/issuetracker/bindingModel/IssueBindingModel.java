package issuetracker.bindingModel;

public class IssueBindingModel {

    // TODO:
}
